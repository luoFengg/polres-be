const { PrismaClient } = require("../../generated/prisma");
const prisma = new PrismaClient();

const setoranSimpanan = async (req, res) => {
  try {
    const { memberId } = req.params;
    const { category, amount, description } = req.body;
    const adminId = req.user.id;

    // Validasi input
    if (!category || !amount) {
      return res.status(400).json({
        success: false,
        message: "Category dan amount wajib diisi",
      });
    }

    // Validasi category
    const validCategories = ["pokok", "wajib", "sukarela", "thr"];
    if (!validCategories.includes(category)) {
      return res.status(400).json({
        success: false,
        message:
          "Kategori simpanan tidak valid. Pilih: pokok, wajib, sukarela, thr",
      });
    }

    // Validasi amount harus positif untuk setoran
    if (amount <= 0) {
      return res.status(400).json({
        success: false,
        message: "Jumlah setoran harus lebih besar dari 0",
      });
    }

    // Cek apakah anggota ada
    const member = await prisma.anggota.findUnique({
      where: { id: memberId },
      include: {
        simpanan: true,
      },
    });

    if (!member) {
      return res.status(404).json({
        success: false,
        message: "Anggota tidak ditemukan",
      });
    }

    // Buat simpanan record jika belum ada
    let simpanan = member.simpanan;
    if (!simpanan) {
      simpanan = await prisma.simpanan.create({
        data: {
          anggotaId: memberId,
          lastUpdatedBy: adminId,
        },
      });
    }

    // Mapping category ke field name
    const categoryFieldMap = {
      pokok: "simpananPokok",
      wajib: "simpananWajib",
      sukarela: "simpananSukarela",
      thr: "tabunganHariRaya",
    };

    const fieldName = categoryFieldMap[category];
    const currentBalance = parseFloat(simpanan[fieldName]) || 0;
    const newBalance = currentBalance + parseFloat(amount);

    // Gunakan transaction untuk konsistensi data
    const result = await prisma.$transaction(async (tx) => {
      // Update balance simpanan
      const updatedSimpanan = await tx.simpanan.update({
        where: { anggotaId: memberId },
        data: {
          [fieldName]: newBalance,
          lastUpdatedBy: adminId,
          updatedAt: new Date(),
        },
      });

      // Catat transaksi
      const transaction = await tx.simpananTransaction.create({
        data: {
          anggotaId: memberId,
          type: "setoran",
          category: category,
          amount: parseFloat(amount),
          balanceBefore: currentBalance,
          balanceAfter: newBalance,
          description: description || `Setoran simpanan ${category}`,
          processedBy: adminId,
          isSystemGenerated: false,
        },
      });

      return { updatedSimpanan, transaction };
    });

    // Get updated simpanan with all balances
    const finalSimpanan = await prisma.simpanan.findUnique({
      where: { anggotaId: memberId },
    });

    res.status(201).json({
      success: true,
      message: "Setoran simpanan berhasil",
      data: {
        transaction: {
          id: result.transaction.id,
          anggotaId: result.transaction.anggotaId,
          type: result.transaction.type,
          category: result.transaction.category,
          amount: result.transaction.amount.toString(),
          balanceBefore: result.transaction.balanceBefore.toString(),
          balanceAfter: result.transaction.balanceAfter.toString(),
          description: result.transaction.description,
          processedBy: result.transaction.processedBy,
          createdAt: result.transaction.createdAt,
        },
        member: {
          nama: member.nama,
          nrp: member.nrp,
        },
        newBalance: {
          simpananPokok: finalSimpanan.simpananPokok.toString(),
          simpananWajib: finalSimpanan.simpananWajib.toString(),
          simpananSukarela: finalSimpanan.simpananSukarela.toString(),
          tabunganHariRaya: finalSimpanan.tabunganHariRaya.toString(),
        },
      },
    });
  } catch (error) {
    console.error("Error in setoranSimpanan:", error);
    res.status(500).json({
      success: false,
      message: "Terjadi kesalahan server",
      error: error.message,
    });
  }
};

module.exports = { setoranSimpanan };
