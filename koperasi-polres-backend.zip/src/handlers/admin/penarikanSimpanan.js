const { PrismaClient } = require("../../generated/prisma");
const prisma = new PrismaClient();

const penarikanSimpanan = async (req, res) => {
  try {
    const { memberId } = req.params;
    const { category, amount, description } = req.body;
    const adminId = req.user.id;

    // Validasi input
    if (!category || !amount) {
      return res.status(400).json({
        success: false,
        message: "Category dan amount wajib diisi",
      });
    }

    // Validasi category
    const validCategories = ["pokok", "wajib", "sukarela", "thr"];
    if (!validCategories.includes(category)) {
      return res.status(400).json({
        success: false,
        message:
          "Kategori simpanan tidak valid. Pilih: pokok, wajib, sukarela, thr",
      });
    }

    // Business Rule: Simpanan pokok tidak bisa ditarik
    if (category === "pokok") {
      return res.status(400).json({
        success: false,
        message: "Simpanan pokok tidak dapat ditarik",
      });
    }

    // Validasi amount harus positif
    if (amount <= 0) {
      return res.status(400).json({
        success: false,
        message: "Jumlah penarikan harus lebih besar dari 0",
      });
    }

    // Cek anggota dan simpanan
    const member = await prisma.anggota.findUnique({
      where: { id: memberId },
      include: {
        simpanan: true,
      },
    });

    if (!member) {
      return res.status(404).json({
        success: false,
        message: "Anggota tidak ditemukan",
      });
    }

    if (!member.simpanan) {
      return res.status(404).json({
        success: false,
        message: "Data simpanan anggota tidak ditemukan",
      });
    }

    // Mapping category ke field name
    const categoryFieldMap = {
      wajib: "simpananWajib",
      sukarela: "simpananSukarela",
      thr: "tabunganHariRaya",
    };

    const fieldName = categoryFieldMap[category];
    const currentBalance = parseFloat(member.simpanan[fieldName]) || 0;

    // Cek saldo mencukupi
    if (currentBalance < parseFloat(amount)) {
      const categoryName = {
        wajib: "simpanan wajib",
        sukarela: "simpanan sukarela",
        thr: "tabungan hari raya",
      };

      return res.status(400).json({
        success: false,
        message: `Saldo ${
          categoryName[category]
        } tidak mencukupi. Saldo saat ini: Rp ${currentBalance.toLocaleString(
          "id-ID"
        )}`,
      });
    }

    const newBalance = currentBalance - parseFloat(amount);

    // Gunakan transaction untuk konsistensi data
    const result = await prisma.$transaction(async (tx) => {
      // Update balance simpanan
      const updatedSimpanan = await tx.simpanan.update({
        where: { memberId: memberId },
        data: {
          [fieldName]: newBalance,
          lastUpdatedBy: adminId,
          updatedAt: new Date(),
        },
      });

      // Catat transaksi (amount negatif untuk penarikan)
      const transaction = await tx.simpananTransaction.create({
        data: {
          memberId: memberId,
          type: "penarikan",
          category: category,
          amount: -parseFloat(amount), // Negatif untuk penarikan
          balanceBefore: currentBalance,
          balanceAfter: newBalance,
          description: description || `Penarikan simpanan ${category}`,
          processedBy: adminId,
          isSystemGenerated: false,
        },
      });

      return { updatedSimpanan, transaction };
    });

    // Get updated simpanan with all balances
    const finalSimpanan = await prisma.simpanan.findUnique({
      where: { memberId: memberId },
    });

    res.status(201).json({
      success: true,
      message: "Penarikan simpanan berhasil",
      data: {
        transaction: {
          id: result.transaction.id,
          memberId: result.transaction.memberId,
          type: result.transaction.type,
          category: result.transaction.category,
          amount: result.transaction.amount.toString(),
          balanceBefore: result.transaction.balanceBefore.toString(),
          balanceAfter: result.transaction.balanceAfter.toString(),
          description: result.transaction.description,
          processedBy: result.transaction.processedBy,
          createdAt: result.transaction.createdAt,
        },
        member: {
          nama: member.nama,
          nrp: member.nrp,
        },
        newBalance: {
          simpananPokok: finalSimpanan.simpananPokok.toString(),
          simpananWajib: finalSimpanan.simpananWajib.toString(),
          simpananSukarela: finalSimpanan.simpananSukarela.toString(),
          tabunganHariRaya: finalSimpanan.tabunganHariRaya.toString(),
        },
      },
    });
  } catch (error) {
    console.error("Error in penarikanSimpanan:", error);
    res.status(500).json({
      success: false,
      message: "Terjadi kesalahan server",
      error: error.message,
    });
  }
};

module.exports = { penarikanSimpanan };
