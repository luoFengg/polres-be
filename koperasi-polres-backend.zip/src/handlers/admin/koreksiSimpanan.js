const { PrismaClient } = require("../../generated/prisma");
const prisma = new PrismaClient();

const koreksiSimpanan = async (req, res) => {
  try {
    const { memberId } = req.params;
    const { category, amount, description } = req.body;
    const adminId = req.user.id;

    // Validasi input
    if (!category || amount === undefined || amount === null) {
      return res.status(400).json({
        success: false,
        message: "Category dan amount wajib diisi",
      });
    }

    // Validasi category
    const validCategories = ["pokok", "wajib", "sukarela", "thr"];
    if (!validCategories.includes(category)) {
      return res.status(400).json({
        success: false,
        message:
          "Kategori simpanan tidak valid. Pilih: pokok, wajib, sukarela, thr",
      });
    }

    // Amount bisa positif (koreksi naik) atau negatif (koreksi turun)
    if (amount === 0) {
      return res.status(400).json({
        success: false,
        message: "Jumlah koreksi tidak boleh 0",
      });
    }

    // Cek anggota dan simpanan
    const member = await prisma.anggota.findUnique({
      where: { id: memberId },
      include: {
        simpanan: true,
      },
    });

    if (!member) {
      return res.status(404).json({
        success: false,
        message: "Anggota tidak ditemukan",
      });
    }

    // Buat simpanan record jika belum ada
    let simpanan = member.simpanan;
    if (!simpanan) {
      simpanan = await prisma.simpanan.create({
        data: {
          memberId: memberId,
          lastUpdatedBy: adminId,
        },
      });
    }

    // Mapping category ke field name
    const categoryFieldMap = {
      pokok: "simpananPokok",
      wajib: "simpananWajib",
      sukarela: "simpananSukarela",
      thr: "tabunganHariRaya",
    };

    const fieldName = categoryFieldMap[category];
    const currentBalance = parseFloat(simpanan[fieldName]) || 0;
    const newBalance = currentBalance + parseFloat(amount);

    // Validasi saldo tidak boleh negatif setelah koreksi
    if (newBalance < 0) {
      return res.status(400).json({
        success: false,
        message: `Koreksi tidak dapat dilakukan. Saldo akan menjadi negatif (${newBalance.toLocaleString(
          "id-ID"
        )})`,
      });
    }

    // Gunakan transaction untuk konsistensi data
    const result = await prisma.$transaction(async (tx) => {
      // Update balance simpanan
      const updatedSimpanan = await tx.simpanan.update({
        where: { memberId: memberId },
        data: {
          [fieldName]: newBalance,
          lastUpdatedBy: adminId,
          updatedAt: new Date(),
        },
      });

      // Catat transaksi
      const transaction = await tx.simpananTransaction.create({
        data: {
          memberId: memberId,
          type: "koreksi",
          category: category,
          amount: parseFloat(amount),
          balanceBefore: currentBalance,
          balanceAfter: newBalance,
          description:
            description ||
            `Koreksi simpanan ${category} sebesar ${
              amount > 0 ? "+" : ""
            }${amount}`,
          processedBy: adminId,
          isSystemGenerated: false,
        },
      });

      return { updatedSimpanan, transaction };
    });

    // Get updated simpanan with all balances
    const finalSimpanan = await prisma.simpanan.findUnique({
      where: { memberId: memberId },
    });

    res.status(201).json({
      success: true,
      message: "Koreksi simpanan berhasil",
      data: {
        transaction: {
          id: result.transaction.id,
          memberId: result.transaction.memberId,
          type: result.transaction.type,
          category: result.transaction.category,
          amount: result.transaction.amount.toString(),
          balanceBefore: result.transaction.balanceBefore.toString(),
          balanceAfter: result.transaction.balanceAfter.toString(),
          description: result.transaction.description,
          processedBy: result.transaction.processedBy,
          createdAt: result.transaction.createdAt,
        },
        member: {
          nama: member.nama,
          nrp: member.nrp,
        },
        newBalance: {
          simpananPokok: finalSimpanan.simpananPokok.toString(),
          simpananWajib: finalSimpanan.simpananWajib.toString(),
          simpananSukarela: finalSimpanan.simpananSukarela.toString(),
          tabunganHariRaya: finalSimpanan.tabunganHariRaya.toString(),
        },
      },
    });
  } catch (error) {
    console.error("Error in koreksiSimpanan:", error);
    res.status(500).json({
      success: false,
      message: "Terjadi kesalahan server",
      error: error.message,
    });
  }
};

module.exports = { koreksiSimpanan };
