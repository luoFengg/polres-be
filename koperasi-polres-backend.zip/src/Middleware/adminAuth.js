const { authenticate } = require("./auth");

// Middleware untuk memastikan user adalah admin
const requireAdmin = (req, res, next) => {
  // Pastikan user sudah ter-authenticate dulu
  if (!req.authenticatedUser) {
    return res.status(401).json({
      success: false,
      message: "Authentication required",
    });
  }

  // Cek apakah role adalah admin
  if (req.authenticatedUser.role !== "admin") {
    return res.status(403).json({
      success: false,
      message: "Access denied. Admin role required",
    });
  }

  next(); // User adalah admin, lanjutkan
};

// Middleware gabungan: authenticate + requireAdmin
const requireAdminAuth = [authenticate, requireAdmin];

module.exports = {
  requireAdmin,
  requireAdminAuth,
};
