const express = require("express");
const router = express.Router();
const { requireAdminAuth } = require("../Middleware/adminAuth");
const { addMember } = require("../handlers/admin/addMember");
const { getAllMembers } = require("../handlers/admin/getAllMembers");
const {
  getMembersPaginated,
} = require("../handlers/admin/getMembersPaginated");
const { getUserDetail } = require("../handlers/shared/getMemberDetail"); // Universal handler
const { addPiutangByUserId } = require("../handlers/admin/addPiutangbyUserId");
const {
  updatePiutangByUserId,
} = require("../handlers/admin/updatePiutangbyUserId");

// Simpanan handlers (unified approach like piutang)
const {
  updateSimpananAnggota,
  getSimpananHistory,
  getAllMembersSimpananSummary,
} = require("../handlers/admin/updateSimpananAnggota");

// Route untuk mendapatkan SEMUA anggota (admin only) - tanpa pagination
router.get("/members/all", requireAdminAuth, getAllMembers);

// Route untuk mendapatkan anggota dengan pagination (admin only)
router.get("/members", requireAdminAuth, getMembersPaginated);

// Route untuk mendapatkan detail anggota + piutang (admin only)
router.get("/members/:memberId", requireAdminAuth, async (req, res) => {
  // Set context untuk admin view
  req.query.context = "admin";
  req.query.includeTransactions = req.query.includeTransactions || "true";

  await getUserDetail(req, res);
});

// Route untuk menambah member baru (admin only)
router.post("/members", requireAdminAuth, addMember);

// Route untuk menambah piutang baru untuk member tertentu (admin only)
router.post("/members/:memberId/piutang", requireAdminAuth, addPiutangByUserId);

// Route untuk update piutang (admin only)
router.patch(
  "/members/:memberId/piutang/:piutangId",
  requireAdminAuth,
  updatePiutangByUserId
);

// ========== SIMPANAN ENDPOINTS (Admin Only) ==========

// Route untuk update simpanan (setoran, penarikan, koreksi) - mirip dengan piutang
router.patch(
  "/members/:memberId/simpanan",
  requireAdminAuth,
  updateSimpananAnggota
);

// Route untuk mendapatkan history transaksi simpanan member tertentu
router.get(
  "/members/:memberId/simpanan/history",
  requireAdminAuth,
  getSimpananHistory
);

// Route untuk mendapatkan summary simpanan semua anggota
router.get("/simpanan/summary", requireAdminAuth, getAllMembersSimpananSummary);

module.exports = router;
