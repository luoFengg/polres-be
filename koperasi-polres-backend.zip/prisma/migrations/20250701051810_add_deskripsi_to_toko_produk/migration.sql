-- AlterTable
ALTER TABLE "TokoProduk" ADD COLUMN     "deskripsi" TEXT;
